
package com.lamichoacana.tamagotchi;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences prefs;
    private int hunger = 80;
    private int sleep = 80;
    private int funLevel = 80;
    private int health = 80;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("tama", MODE_PRIVATE);
        loadState();

        TextView tvMood = findViewById(R.id.tvMood);
        ProgressBar barHunger = findViewById(R.id.barHunger);
        ProgressBar barSleep = findViewById(R.id.barSleep);
        ProgressBar barFun = findViewById(R.id.barFun);
        ProgressBar barHealth = findViewById(R.id.barHealth);
        Button btnFeed = findViewById(R.id.btnFeed);
        Button btnSleep = findViewById(R.id.btnSleep);
        Button btnPlay = findViewById(R.id.btnPlay);
        Button btnHeal = findViewById(R.id.btnHeal);
        Button btnReset = findViewById(R.id.btnReset);

        Runnable refresh = () -> {
            barHunger.setProgress(hunger);
            barSleep.setProgress(sleep);
            barFun.setProgress(funLevel);
            barHealth.setProgress(health);
            tvMood.setText(moodText());
        };

        btnFeed.setOnClickListener(v -> { hunger = Math.min(100, hunger + 10); saveState(); refresh.run(); });
        btnSleep.setOnClickListener(v -> { sleep = Math.min(100, sleep + 10); saveState(); refresh.run(); });
        btnPlay.setOnClickListener(v -> { funLevel = Math.min(100, funLevel + 10); saveState(); refresh.run(); });
        btnHeal.setOnClickListener(v -> { health = Math.min(100, health + 10); saveState(); refresh.run(); });
        btnReset.setOnClickListener(v -> { hunger=80; sleep=80; funLevel=80; health=80; saveState(); refresh.run(); });

        refresh.run();
    }

    private String moodText() {
        int avg = (hunger + sleep + funLevel + health) / 4;
        if (avg >= 80) return "😊 Feliz — La Michoacana";
        if (avg >= 50) return "😐 Normal — La Michoacana";
        if (avg >= 30) return "😟 Triste — La Michoacana";
        return "🤒 Enfermo — La Michoacana";
    }

    private void saveState() {
        prefs.edit()
                .putInt("hunger", hunger)
                .putInt("sleep", sleep)
                .putInt("fun", funLevel)
                .putInt("health", health)
                .apply();
    }

    private void loadState() {
        hunger = prefs.getInt("hunger", 80);
        sleep = prefs.getInt("sleep", 80);
        funLevel = prefs.getInt("fun", 80);
        health = prefs.getInt("health", 80);
    }
}
